<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
             echo $_GET['cardtype'];
              echo $_GET['cardamount'];echo $_POST['cardtype'];
              echo $_POST['cardamount'];
        ?>
    </body>
</html>
