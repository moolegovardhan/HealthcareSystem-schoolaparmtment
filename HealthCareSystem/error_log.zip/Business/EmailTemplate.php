<?php

$message = "<html>";
$message .= "<head>";
$message .= '<style type="text/css">';
$message .= '.tg  {border-collapse:collapse;border-spacing:0;border-color:#aaa;margin:0px auto;}';
$message .= '.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#aaa;color:#333;background-color:#fff;}';
$message .= '.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#aaa;color:#fff;background-color:#f38630;}';
$message .= '.tg .tg-jz43{font-family:"Comic Sans MS", cursive, sans-serif !important;;background-color:#ffccc9}';
$message .= '.tg .tg-7chs{font-style:italic;font-family:"Palatino Linotype", "Book Antiqua", Palatino, serif !important;;background-color:#efefef}';
$message .= '.tg .tg-e3zv{font-weight:bold}';
$message .= '.tg .tg-w82q{font-family:"Comic Sans MS", cursive, sans-serif !important;}';
$message .= '@media screen and (max-width: 767px) {.tg {width: auto !important;}.tg col {width: auto !important;}.tg-wrap {overflow-x: auto;-webkit-overflow-scrolling: touch;margin: auto 0px;}}</style>';
$message .= "</head>";

$message .= "<body>";
       
$message .= '<div class="tg-wrap"><table class="tg">';
$message .= "  <tr>";
$message .="    <th class='tg-e3zv'>Patient Name</th>";
$message .= "    <th class='tg-w82q' colspan='2'></th>";
$message .= "  </tr>";
 $message .= " <tr>";
$message .= "    <td class='tg-jz43'>Medicine Names</td>";
$message .= "    <td class='tg-jz43'>No Of Days</td>";
$message .= "    <td class='tg-jz43'>Total Quantity</td>";
$message .= "  </tr>";
$message .= "  <tr>";
$message .= "      <td class='tg-7chs'></td>";
 $message .= "     <td class='tg-7chs'></td>";
$message .= "      <td class='tg-7chs'></td>";
$message .= "    </tr>";
$message .= "  </table></div>";
$message .= "      </body>";
$message .= "  </html>";
?>