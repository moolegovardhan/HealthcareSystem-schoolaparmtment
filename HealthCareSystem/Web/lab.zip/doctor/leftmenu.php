 <div class="col-md-3  alert-warning">
     
    
     <hr/>
     <b>Total Appointments :</b>&nbsp;&nbsp;&nbsp;&nbsp;<i>50</i>
     <hr/>
      <!--b>Doctor's Available :</b>
        <div>
            <justify>  
            <li><i>Pavan Kumar</i></li>
             <li><i>Hari Krishna</i></li>
              <li><i>Sridhar</i></li>
             </justify>
            <hr/>
        </div>
      <b>Doctor's Absent :</b>
        <div>
            <justify>  
            <li><i>Rajiv Shukla</i></li>
             <li><i>Damodar Reddy</i></li>
              <li><i>Dr Sasank</i></li>
             </justify>
            <hr/>
        </div>
       <ul class="list-group sidebar-nav-v1" id="sidebar-nav">
                 
            <li class="list-group-item list-toggle">                   
                <a data-toggle="collapse" data-parent="#sidebar-nav" href="#collapse-typography">Disease</a>
                <ul id="collapse-typography" class="collapse">
                    <li><a href="#">Symptoms</a></li>
                    <li>
                        <a href="#">Precautions</a>
                    </li>
                    <li>                           
                        <a href="#"> Dividers</a>
                    </li>

                    <li>                           
                        <a href="#">Food taken</a>
                    </li>
                    <li><a href="#"> Food avoids</a></li>                            
                </ul>
            </li> 

            <li class="list-group-item"><a href="#">Pregnancy care</a></li> 

            <li class="list-group-item"><a href="#">Child care</a></li> 

            <li class="list-group-item"><a href="#"> Old age care</a></li> 

            <li class="list-group-item"><a href="#">Nutrition</a></li> 

            <li class="list-group-item"><a href="#">Yoga</a></li> 

            <li class="list-group-item"><a href="#">Meditation</a></li> 
             <li class="list-group-item"><a href="#">Side effects </a></li>

            <li class="list-group-item"><a href="#">Rejected Medicine list</a></li> 
        </ul-->
        
        
        <!--ul class="list-group sidebar-nav-v1" id="sidebar-nav">
           
            <li class="list-group-item list-toggle">                   
                <a data-toggle="collapse" data-parent="#sidebar-nav" href="#collapse-typography">Profile</a>
                <ul id="collapse-typography" class="collapse">
                    <li><a href="patientindex.php?page=personal">Personal</a></li>
                    <li>
                        <a href="patientindex.php?page=health">Health</a>
                    </li>
                                            
                </ul>
            </li> 

            <li class="list-group-item"><a href="patientindex.php?page=consultation">Consultation</a></li> 

            <li class="list-group-item"><a href="#">Medicine</a></li> 

            <li class="list-group-item"><a href="patientindex.php?page=reports">Reports</a></li> 

        </ul-->
</div>